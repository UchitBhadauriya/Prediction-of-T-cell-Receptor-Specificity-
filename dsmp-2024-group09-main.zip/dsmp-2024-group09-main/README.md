# Group Repository for the Data Science Mini-Project (EMATM0050)

## Please edit the fields below with your information
Group Number: 09

Problem Assigned: A

Group Members: Uchit Bhadauriya, Letian Zhang, Yu Gu, Lubin Wan

